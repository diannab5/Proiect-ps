#reprezentarea grafica a datelor
import pandas as pd
import matplotlib.pyplot as plt
pd.set_option("display.max_columns",10)
df = pd.read_csv('Produse.csv')
print(df['Pret'])
df['Pret'].plot(kind='bar')
plt.xlabel('id_furnizor')
plt.ylabel('Pret')
plt.show()