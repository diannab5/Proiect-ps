import pandas as pd

# Crearea si afisarea unei liste
lista=[1,5,6,7,8,9,10,12,14,15,16,18,19]
print(lista)

# Accesare element lista pe baza unui index
print(lista[3])

# Adaugarea unui element in lista
lista.append(20)
print(lista)

# Eliminarea id-ului 12 din lista
del lista[7]
print(lista)

# Crearea si afisarea unui dictionar
dictionar = {"nume":"Popescu", "varsta":"34", "adresa":"Strada Fizicienilor"}
print(dictionar)

# Accesare element dictionar pe baza cheii
print(dictionar.get("nume"))

# Modificarea unui element din dictionar
dictionar["adresa"] = "Strada Fizicienilor nr.12"
print(dictionar)
print()

# Crearea si afisarea unui set
set={"Laptop HP", "Asus Gaming", "Dell Inspiron", "HP Gaming Omen","Xiaomi Redmi","Horizon Diamant"}
print(set)

# Adaugarea unui element in set
set.add("DELL Laptop")
print(set)

# Eliminarea unui element din set
set.discard("Asus Gaming")
print(set)

# Eliminarea tuturor elementelor setului
set.clear()
print()

# Crearea si afisarea unui tuplu
tuplu={"Asus Gaming", "Dell Inspiron","Laptop HP","Xiaomi Redmi","Horizon Diamant", "HP Gaming Omen","Asus Gaming"}
print(tuplu)

#Lista cu preturi
listaP=[1498.99,2498.99,1298.99,3598.99,1699.99,2149.99,3849.99,3399.99,499.99,1498.99,348.99,
       1578.99,388.99,598.99,307.99,99.99,37.99,76.48,268.99,378.98,984.17]

#definirea functiei
def func(lista):
    for x in lista:
        if x < 1500:
            x=x+100
        print(x)

#apelarea functiei
func(listaP)

#Lista cu cantitatile produselor
listaC=[3,4,5,4,5,7,4,6,14,5,13,10,13,5,6,5,5,3,4,6,3]

#folosirea structurilor conditionale
sum=0
for x in listaC:
    if x > 5:
        sum+=1
print("Produsele in cantitate mai mare de 5 bucati sunt in numar de: " ,sum)

#Lista cu valoare totala a produselor
listaVT=[4496.97,9995.96,6494.95,14395.96,8499.95,15049.93,15399.96,20399.94,6999.86,7494.95,4536.87,15789.9,5056.87
            ,2994.95,1847.94,499.95,189.95,229.44,1075.96,2273.88,2952.51]

#folosirea structurilor repetitive
for idx, element in enumerate(listaVT):
    print("Produsul cu numarul: " ,idx, " are valoarea totala= ", element)


fisier = pd.read_csv('fisier.csv')
print(fisier.iloc[2])

print(fisier.loc[:,['Categorie','Cantitate','Pret']])


#print(fisier.drop(["Furnizor"], axis = 1, inplace = True))
#print(fisier.set_value(2, "Cantitate", 10))

# Functii de grup
print('Cantitatea totala pentru fiecare categorie')
print(fisier.groupby('Categorie')['Cantitate'].sum())
print('Valoarea totala maxima pentru fiecare categorie')
print(fisier.groupby('Categorie')['Valoare totala'].max())

# Prelucrare seturi de date
df = pd.read_csv('Produse.csv')
df1 = pd.read_csv('Furnizori.csv')

result = pd.merge(df,
                  df1[['id_furnizor', 'Nr telefon', 'Cantitate produsa']],
                  on='id_furnizor')
print(result)
print('Structura fisierului Produse.csv ', df.shape)
print('Structura fisierului Furnizori.csv ', df1.shape)
print(df['id_furnizor'].isin(df1['id_furnizor']).value_counts())

# Prelucrari statistice, gruparea si agregarea datelor în pachetul pandas
df = pd.read_csv('fisier.csv')
df1 = df.groupby(['Categorie']).agg({'Cantitate': ['mean', 'min', 'max']})
df1.to_csv('agregaref.csv')

